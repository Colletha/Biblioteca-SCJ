<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class DashboardController extends Controller
{
    public function index()
    {
        $data = [
            'title' => 'Dashboard',
            'username' => session()->get('username'),
            'email' => session()->get('email')
        ];

        return view('dashboard/index', $data);
    }
}